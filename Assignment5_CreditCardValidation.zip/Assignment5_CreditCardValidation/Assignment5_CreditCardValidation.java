public class Assignment5_CreditCardValidation {
    public static void main(String[]args);{
        String input = "4388 5760 1840 2626";
        System.out.println(validateCreditCardNumber(input));

    }
    private static boolean validateCreditCardNumber(String input){

        // Cover input to int
        int[]creditCardInt = new int[input.length()];
        for (int i = 0; i < input.length(); i++){
            creditCardInt[i] = Interger.parseInt(intput.substring(i, i + 1));
        }
        //
        for (int i = creditCardInt.length -2;  i >= 0; i = i-2){
            int tempValue = creditCardInt[i];
            tempValue = tempValue * 2;
            if (tempValue > 9){
                tempValue % 10 + 1;
            }
            creditCardInt[i] = tempValue;
        }

        //
        int total = 0;
        for (int i = 0; 1 < creditCardInt.length; i++){
            total+= creditCardInt[i];
        }

        //
        if (toal % 10 ==0){
            return valid;
        }
        else {
            return invalid;
        }
    }

}
